#include "common/constants.h"
#include "common/io.h"
#include "operations.h"

void initialize_client(char *req_pipe,char *resp_pipe, char *msg_received) {
  memcpy(req_pipe, "../client/", 10);
  memcpy(resp_pipe, "../client/", 10);    
  for(int i = 2; i < MAX_PIPENAME_SIZE + 1; i++){
    if(msg_received[i] != '\0')
      req_pipe[10 + i-2] = msg_received[i];
  }

  for(int j = MAX_PIPENAME_SIZE + 3; j < MAX_PIPENAME_SIZE + 3 + MAX_PIPENAME_SIZE; j++){
    if(msg_received[j] != '\0')
      resp_pipe[10 + j-(MAX_PIPENAME_SIZE + 3)] = msg_received[j];  
  }

  printf("REQ PIPE: %s\n",req_pipe);
  printf("RESP PIPE: %s\n",resp_pipe);
}

int main(int argc, char* argv[]) {
  if (argc < 2 || argc > 3) {
    fprintf(stderr, "Usage: %s\n <pipe_path> [delay]\n", argv[0]);
    return 1;
  }

  char* endptr;
  unsigned int state_access_delay_us = STATE_ACCESS_DELAY_US;
  if (argc == 3) {
    unsigned long int delay = strtoul(argv[2], &endptr, 10);

    if (*endptr != '\0' || delay > UINT_MAX) {
      fprintf(stderr, "Invalid delay value or value too large\n");
      return 1;
    }

    state_access_delay_us = (unsigned int)delay;
  }

  if (ems_init(state_access_delay_us)) {
    fprintf(stderr, "Failed to initialize EMS\n");
    return 1;
  }

  //TODO: Intialize server, create worker threads
  static char *server_pipe;
  char req_client_pipe[MAX_PIPENAME_SIZE+10];
  char resp_client_pipe[MAX_PIPENAME_SIZE+10];
  server_pipe = argv[1];

  // Remove server pipe if it does exist
  if (unlink(server_pipe) != 0 && errno != ENOENT) {
    fprintf(stdout, "ERROR unlink(%s) failed:\n", server_pipe);
    exit(EXIT_FAILURE);
  }

  // Create server pipe
  if (mkfifo(server_pipe, 0666) != 0) {
    fprintf(stdout, "ERROR mkfifo failed for pipe %s\n", server_pipe);
    exit(EXIT_FAILURE);
  }
  printf("SERVER PIPE OPEN\n");

  // Open server pipe for reading
  // This waits for someone to open it for writing
  int fd_server = open(server_pipe, O_RDONLY);
  if (fd_server == -1) {
    fprintf(stderr, "[ERR]: open failed: %s\n", strerror(errno));
    exit(EXIT_FAILURE);
  }
  printf("SERVER PIPE WAITING TO READ\n");

  char msg_received[EMS_SETUP_MESSAGE_2_SERVER];
  ssize_t ret = read(fd_server, msg_received, EMS_SETUP_MESSAGE_2_SERVER);
  if (ret < 0) {
    fprintf(stdout, "ERR: read failed\n");
    exit(EXIT_FAILURE);
  }
  
  if(msg_received[0] == '1')
    initialize_client(req_client_pipe, resp_client_pipe, msg_received);

  fprintf(stdout, "[INFO]: received %zd B\n", ret);

  while (1) {
    //TODO: Read from pipe
    //TODO: Write new client to the producer-consumer buffer
  }

  //TODO: Close Server
  close(fd_server);

  ems_terminate();
}