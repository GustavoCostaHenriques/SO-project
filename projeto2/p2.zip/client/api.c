#include "api.h"
#include "common/io.h"
#include "common/constants.h"

int ems_setup(char const* req_pipe_path, char const* resp_pipe_path, char const* server_pipe_path) {
  //TODO: create pipes and connect to the server

  // Open server pipe for writing
  // This waits for someone to open it for reading
  int fd_server = open(server_pipe_path, O_WRONLY);
  if (fd_server == -1) {
    fprintf(stderr, "[ERR]: open failed: %s\n", strerror(errno));
    exit(EXIT_FAILURE);
  }
  printf("SERVER PIPE WAITING TO WRITE\n");

  // Remove req_pipe_path if it does exist
  if (unlink(req_pipe_path) != 0 && errno != ENOENT) {
    fprintf(stdout, "ERROR unlink(%s) failed:\n", req_pipe_path);
    exit(EXIT_FAILURE);
  }

  // Remove resp_pipe_path if it does exist
  if (unlink(resp_pipe_path) != 0 && errno != ENOENT) {
    fprintf(stdout, "ERROR unlink(%s) failed:\n", resp_pipe_path);
    exit(EXIT_FAILURE);
  }

  // Create req_pipe_path
  if (mkfifo(req_pipe_path, 0666) != 0) {
    fprintf(stdout, "ERROR mkfifo failed for pipe %s\n", req_pipe_path);
    exit(EXIT_FAILURE);
  }
  printf("REQUEST PIPE OPEN\n");

  // Create resp_pipe_path
  if (mkfifo(resp_pipe_path, 0666) != 0) {
    fprintf(stdout, "ERROR1 mkfifo failed for pipe %s\n", resp_pipe_path);
    //exit(EXIT_FAILURE);
  }
  printf("RESPONSE PIPE OPEN\n"); 

  const char *message_fields[4];
  message_fields[0] = "1|";

  char req_pipe_path_fixed[MAX_JOB_FILE_NAME_SIZE];
  fill_string(req_pipe_path, req_pipe_path_fixed);
  message_fields[1] = req_pipe_path_fixed;

  message_fields[2] = "|";

  char resp_pipe_path_fixed[MAX_JOB_FILE_NAME_SIZE];
  fill_string(resp_pipe_path, resp_pipe_path_fixed);
  message_fields[3] = resp_pipe_path_fixed;

  char *message_sent;
  const size_t string_sizes[] = {2, 40, 1, 40};
  build_string(&message_sent, message_fields, 4, string_sizes, EMS_SETUP_MESSAGE_2_SERVER);

  send_msg(fd_server, message_sent);
  free(message_sent);
  close(fd_server);
  return 1;
}

int ems_quit(void) { 
  //TODO: close pipes
  return 1;
}

int ems_create(unsigned int event_id, size_t num_rows, size_t num_cols) {
  //TODO: send create request to the server (through the request pipe) and wait for the response (through the response pipe)
  (void) event_id;
  (void) num_rows;
  (void) num_cols;
  return 1;
}

int ems_reserve(unsigned int event_id, size_t num_seats, size_t* xs, size_t* ys) {
  //TODO: send reserve request to the server (through the request pipe) and wait for the response (through the response pipe)
  (void) event_id;
  (void) num_seats;
  (void) xs;
  (void) ys;
  return 1;
}

int ems_show(int out_fd, unsigned int event_id) {
  //TODO: send show request to the server (through the request pipe) and wait for the response (through the response pipe)
  (void) out_fd;
  (void) event_id;
  return 1;
}

int ems_list_events(int out_fd) {
  //TODO: send list request to the server (through the request pipe) and wait for the response (through the response pipe)
  (void) out_fd;
  return 1;
}
